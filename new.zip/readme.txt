How to build docker file and set name
	docker build -t  set-name:latest .
How to tag file
	docker tag docker-image-name gcr.io/project-id/docker-image-name
How to push to repo
	docker push docker-image-name
